package {{packageName}};

import org.junit.Test;
import org.junit.runner.RunWith;
{{testImports}}
@RunWith(SpringRunner.class)
@SpringBootTest
{{testAnnotations}}public class {{applicationName}}Tests {

	@Test
	public void contextLoads() {
	}

}

