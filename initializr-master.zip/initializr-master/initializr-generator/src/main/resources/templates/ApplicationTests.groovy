package {{packageName}}

import org.junit.Test
import org.junit.runner.RunWith
{{testImports}}
@RunWith(SpringRunner)
@SpringBootTest
{{testAnnotations}}class {{applicationName}}Tests {

	@Test
	void contextLoads() {
	}

}

